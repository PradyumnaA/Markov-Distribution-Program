#Initial Reward for each state is mentioned here
rewards = [-0.1, -0.1, -0.1, -4, 2, 5, -2]
#Transition Probability for walk is mentioned here
walk_transition_probabilities = [
    [0.5, 0.5, 0, 0, 0, 0, 0],
    [0, 0, 0, 0.5, 0.5, 0, 0],
    [0, 0, 0.5, 0, 0, 0.5, 0]
]
#Transition Probability for teleport is mentioned here
teleport_transition_probabilities = [
    [0, 0.5, 0.5, 0, 0, 0, 0],
    [0, 0, 0.25, 0.75, 0, 0, 0],
    [0, 0, 0, 0, 0, 0.5, 0.5]
]



#Total number of states= size of rewards list
#Here we have s1 to s7
number_of_states = len(rewards)

#Caluclating the utility here
#To faster the speed of execution we are memoisating it
#Here we are storing the previous values using the concept of memoisation
def calculate_utility(iteration, state_index, discount_factor, memoisation):
    """
    Function to recursively caluclate the next states values by making use of bellman ford equation
    Ut+1(Si) = max_a [R(Si) + γ * Σ [P(Sj | Si, a) * Ut(Sj)]]
    
    """
    #If the iteration is zero and the index of state is lesser than 3 we are returning the zero
    if iteration == 0 and state_index < 3:
        return 0
    elif iteration == 0:#Otherwise if the iteration is zero we are returning the rewards of states
        return rewards[state_index]
    elif state_index >= 3:#If the state index is greater than 3 we are returning the rewards of states
        return rewards[state_index]


    if (iteration, state_index) in memoisation:#If the iteration and state_index is present in the memoisationn return the respective iteration and index
        return memoisation[(iteration, state_index)]

    # Calculate utility recursively
    walking_utility = rewards[state_index] + discount_factor * sum(
        walk_transition_probabilities[state_index][j] * calculate_utility(iteration-1, j, discount_factor, memoisation)
        for j in range(number_of_states)
    )
    """
    Function to recursively caluclate the next states values by making use of bellman ford equation
    Ut+1(Si) = max_a [R(Si) + γ * Σ [P(Sj | Si, walk) * Ut(Sj)]]
    
    """

    teleporting_utility = rewards[state_index] + discount_factor * sum(
        teleport_transition_probabilities[state_index][j] * calculate_utility(iteration-1, j, discount_factor, memoisation)
        for j in range(number_of_states)
    )
    """
    Function to recursively caluclate the next states values by making use of bellman ford equation
    Ut+1(Si) = max_a [R(Si) + γ * Σ [P(Sj | Si, teleport) * Ut(Sj)]]
    """

    #Here we are returning the maximum value of teleporting and walking utility
    result = max(teleporting_utility, walking_utility)
    """
    Function to recursively caluclate the next states values by making use of bellman ford equation
    Ut+1(Si) = max_a [R(Si) + γ * Σ [P(Sj | Si, walk,teleport) * Ut(Sj)]]
    """

    # Memoize the result and storing it for next caluclation
    memoisation[(iteration, state_index)] = result
    return result

def value_iteration(discount_factor):
    """
    This function calls the caluclate utility function and returns the values as tuple
    """
    memoisation = {}

    # Calculate utilities for different states and iterations
    V0_S1 = calculate_utility(0, 0, discount_factor, memoisation)
    V0_S2 = calculate_utility(0, 1, discount_factor, memoisation)
    V0_S3 = calculate_utility(0, 2, discount_factor, memoisation)

    V1_S1 = calculate_utility(1, 0, discount_factor, memoisation)
    V1_S2 = calculate_utility(1, 1, discount_factor, memoisation)
    V1_S3 = calculate_utility(1, 2, discount_factor, memoisation)

    V2_S1 = calculate_utility(2, 0, discount_factor, memoisation)
    V2_S2 = calculate_utility(2, 1, discount_factor, memoisation)
    V2_S3 = calculate_utility(2, 2, discount_factor, memoisation)

    return V0_S1, V0_S2, V0_S3, V1_S1, V1_S2, V1_S3, V2_S1, V2_S2, V2_S3

#Values are printed in the below lines
result_discount_1 = value_iteration(1)
# Part c: Value iteration with discount factor = 0.95 until convergence
result_discount_095 = value_iteration(0.95)


V0_S1, V0_S2, V0_S3, V1_S1, V1_S2, V1_S3, V2_S1, V2_S2, V2_S3=value_iteration(1)#Unmapping the tuple
print("V0_S1 is",V0_S1)
print("V0_S2 is",V0_S2)
print("V0_S3 is",V0_S3)

print("V1_S1 is",V1_S1)
print("V1_S2 is",V1_S2)
print("V1_S3 is",V1_S3)

print("V2_S1 is",V2_S1)
print("V2_S2 is",V2_S2)
print("V2_S3 is",V2_S3)

# Part c: Value iteration with discount factor = 0.95 until convergence
V0_S1, V0_S2, V0_S3, V1_S1, V1_S2, V1_S3, V2_S1, V2_S2, V2_S3=value_iteration(0.95)
print("\nDiscount Factor = 0.95 ")
print("V0_S1 is",V0_S1)
print("V0_S2 is",V0_S2)
print("V0_S3 is",V0_S3)

print("V1_S1 is",V1_S1)
print("V1_S2 is",V1_S2)
print("V1_S3 is",V1_S3)

print("V2_S1 is",V2_S1)
print("V2_S2 is",V2_S2)
print("V2_S3 is",V2_S3)

def extract_optimal_policy(utilities_values, discount_factor):
    """
    This function is used to extract the optimal policy
    """
    #Python code to extract the optimal policy
    optimal_policy = []#Defining the optimal policy here

    for state_index in range(3):#For 3 states do the following
        walking_utility = rewards[state_index] + discount_factor * sum(
            walk_transition_probabilities[state_index][j] * utilities_values[state_index + 3]
            for j in range(number_of_states)
        )#Calculating the walking utility

        teleporting_utility = rewards[state_index] + discount_factor * sum(
            teleport_transition_probabilities[state_index][j] * utilities_values[state_index + 3]
            for j in range(number_of_states)
        )#Caluclating the teleporting utility

        # Choose the action that maximizes the expected utility
        if teleporting_utility > walking_utility:#If the teleporting utility is greater than walking utility then append the teleport to optimal policy
            optimal_policy.append("TELEPORT")
        else:
            optimal_policy.append("WALK")#otherwise append walk to the optimal policy

    return optimal_policy#Ultimately return the optimal policy
optimal_policy_discount_1 = extract_optimal_policy(result_discount_1, 1)
print("\nOptimal Policy (Discount Factor = 1 after two iterations):", optimal_policy_discount_1)

# Extract and print the optimal policy for discount factor = 0.95 after convergence
optimal_policy_discount_095 = extract_optimal_policy(result_discount_095, 0.95)
print("\nOptimal Policy (Discount Factor = 0.95 after convergence):", optimal_policy_discount_095)
